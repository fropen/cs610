./selectKthElem 10000 rand10k.txt 5000
