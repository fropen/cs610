./selectKthElem 100000 rand100k.txt 50000
