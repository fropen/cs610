./selectKthElem 1000000 rand1000k.txt 500000
