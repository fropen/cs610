./selectKthElem 10000000 rand10m.txt 5000000
